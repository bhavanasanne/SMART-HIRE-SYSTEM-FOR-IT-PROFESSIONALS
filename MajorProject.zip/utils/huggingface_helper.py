import requests
from utils.token_tracker import log_api_call
import streamlit as st


def suggest_resume_improvements(text, role, hf_api_key):
    prompt = f"""
Resume:
{text}
provide the improvement suggestions for the best matched role for the resume and do not print anything from resume:
"""
    return _query_huggingface_model(prompt, hf_api_key)


def suggest_skills_to_add(text, role, hf_api_key):
    prompt = (f"You are an expert job coach.\n"
    f"Return a clean list of additional skills this person should include for the role of '{role}'.\n"
    f"Resume:\n{text}\n"
    f"Suggested skills:\n")
    return _query_huggingface_model(prompt, hf_api_key)

"""def _query_huggingface_model(prompt, hf_api_key):
    API_URL = "https://api-inference.huggingface.co/models/mistralai/Mixtral-8x7B-Instruct-v0.1"
    headers = {"Authorization": f"Bearer {hf_api_key}"}
    payload = {"inputs": prompt}

    response = requests.post(API_URL, headers=headers, json=payload)
    if response.status_code == 429:
        return "⚠️ Hugging Face API: Rate limit exceeded. Please try again later."
    if not response.ok:
        return f"⚠️ Error from Hugging Face API: {response.text}"
    
    try:
        result = response.json()
        return result[0]["generated_text"] if isinstance(result, list) else str(result)
    except Exception as e:
        return f"⚠️ Failed to parse Hugging Face response: {e}"""
    
def _query_huggingface_model(prompt, hf_api_key):
    API_URL = "https://api-inference.huggingface.co/models/mistralai/Mixtral-8x7B-Instruct-v0.1"
    headers = {"Authorization": f"Bearer {hf_api_key}"}
    payload = {"inputs": prompt}

    response = requests.post(API_URL, headers=headers, json=payload)

    if response.status_code == 429:
        return "⚠️ Hugging Face API: Rate limit exceeded. Please try again later."
    if not response.ok:
        return f"⚠️ Error from Hugging Face API: {response.text}"

    try:
        result = response.json()
        
        # Track calls and tokens manually
        st.session_state.hf_api_calls += 1
        st.session_state.hf_token_count += len(prompt.split())

        return result[0]["generated_text"] if isinstance(result, list) else str(result)
    except Exception as e:
        return f"⚠️ Failed to parse Hugging Face response: {e}"


"""def _query_huggingface_model(prompt, hf_api_key):
    API_URL = "https://api-inference.huggingface.co/models/mistralai/Mixtral-8x7B-Instruct-v0.1"
    headers = {"Authorization": f"Bearer {hf_api_key}"}
    payload = {"inputs": prompt}

    response = requests.post(API_URL, headers=headers, json=payload)
    
    if response.status_code == 429:
        return "⚠️ Hugging Face API: Rate limit exceeded. Please try again later."
    if not response.ok:
        return f"⚠️ Error from Hugging Face API: {response.text}"

    try:
        result = response.json()
        token_count = len(prompt.split())  # crude token estimate
        log_api_call(token_count)
        return result[0]["generated_text"] if isinstance(result, list) else str(result)
    except Exception as e:
        return f"⚠️ Failed to parse Hugging Face response: {e}"""
