def find_best_role(extracted_skills, ats_keywords):
    """
    Find the best-matched job role from ats_keywords using a weighted skill match.
    """
    best_match = None
    highest_score = 0

    for role, keywords in ats_keywords.items():
        mandatory = set(keywords["mandatory"])
        optional = set(keywords["optional"])
        extracted = set(extracted_skills)

        matched_mandatory = len(mandatory & extracted)
        matched_optional = len(optional & extracted)
        total_score = matched_mandatory * 2 + matched_optional  # Weighted: mandatory has more weight

        if total_score > highest_score:
            highest_score = total_score
            best_match = role

    return best_match if best_match else "None Matched"


def calculate_weighted_ats_score(skills, keywords):
    """
    Calculates a weighted ATS score based on matched mandatory and optional keywords.
    """
    matched_mandatory = len(set(keywords["mandatory"]) & set(skills))
    matched_optional = len(set(keywords["optional"]) & set(skills))
    total_mandatory = len(keywords["mandatory"])
    total_optional = len(keywords["optional"])

    mandatory_score = (matched_mandatory / total_mandatory) * 0.7 if total_mandatory else 0
    optional_score = (matched_optional / total_optional) * 0.3 if total_optional else 0

    return round((mandatory_score + optional_score) * 100, 2)


def get_missing_keywords(skills, keywords):
    """
    Returns the list of missing mandatory and optional keywords.
    """
    missing = {
        "mandatory": list(set(keywords["mandatory"]) - set(skills)),
        "optional": list(set(keywords["optional"]) - set(skills))
    }
    return missing
