import json
import os
from datetime import datetime

TOKEN_LOG_PATH = "data/token_usage.json"

def load_token_log():
    if os.path.exists(TOKEN_LOG_PATH):
        with open(TOKEN_LOG_PATH, "r") as f:
            return json.load(f)
    return {
        "total_calls": 0,
        "total_tokens": 0,
        "log": []
    }

def save_token_log(data):
    os.makedirs(os.path.dirname(TOKEN_LOG_PATH), exist_ok=True)
    with open(TOKEN_LOG_PATH, "w") as f:
        json.dump(data, f, indent=2)

def log_api_call(token_count):
    data = load_token_log()
    data["total_calls"] += 1
    data["total_tokens"] += token_count
    data["log"].append({
        "timestamp": datetime.now().isoformat(),
        "tokens_used": token_count
    })
    save_token_log(data)

def get_token_summary():
    data = load_token_log()
    return {
        "Total API Calls": data["total_calls"],
        "Total Tokens Used": data["total_tokens"]
    }
