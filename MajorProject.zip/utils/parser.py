import fitz  # PyMuPDF
import re
import spacy
from rapidfuzz import fuzz

# Load English language model (make sure it's installed via `python -m spacy download en_core_web_sm`)
try:
    nlp = spacy.load("en_core_web_sm")
except:
    raise RuntimeError("⚠️ Please install the SpaCy model with: python -m spacy download en_core_web_sm")

def extract_text_from_pdf(file):
    """Extracts all text from a PDF file object."""
    doc = fitz.open(stream=file.read(), filetype="pdf")
    text = ""
    for page in doc:
        text += page.get_text("text")
    return text

def extract_basic_info(text):
    """Extracts email and phone number from text."""
    email = re.findall(r"[\w\.-]+@[\w\.-]+", text)
    phone = re.findall(r"\+?\d[\d\s\-]{8,}\d", text)
    return {
        "email": email[0] if email else "Not Found",
        "phone": phone[0] if phone else "Not Found"
    }

def extract_skills(text, all_keywords):
    """
    Extracts matched skills from resume text using exact keyword matching.
    Can be extended with fuzzy or NLP matching if needed.
    """
    matched = set()
    for kw in all_keywords:
        pattern = rf"\b{re.escape(kw)}\b"
        if re.search(pattern, text, re.IGNORECASE):
            matched.add(kw)
    return sorted(matched)
