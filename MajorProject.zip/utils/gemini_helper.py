import requests

def get_gemini_suggestions(prompt, api_key):
    url = f"https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key={api_key}"
    headers = {"Content-Type": "application/json"}
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": prompt}
                ]
            }
        ]
    }

    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()["candidates"][0]["content"]["parts"][0]["text"]
    except requests.exceptions.HTTPError as http_err:
        return f"⚠️ HTTP error: {http_err}"
    except Exception as e:
        return f"⚠️ Error from Gemini API: {str(e)}"

def suggest_resume_improvements(text, role, api_key):
    """Suggests improvements for the resume using Gemini API."""
    try:
        prompt = f"""
        You are a resume expert. Analyze the following resume text and suggest specific improvements to better match the role of a {role}.
        Resume:
        {text}
        """
        response = requests.post(
            f"https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key={api_key}",
            headers={"Content-Type": "application/json"},
            json={"contents": [{"parts": [{"text": prompt}]}]}
        )
        response.raise_for_status()
        data = response.json()
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as e:
        return f"⚠️ Error from Gemini API: {e}"

def suggest_skills_to_add(text, role, api_key):
    """Suggests additional skills to add to the resume for a specific role using Gemini."""
    try:
        prompt = f"""
        Analyze the resume text below and suggest 5–10 technical and soft skills the candidate should consider adding to better align with the {role} role.
        Resume:
        {text}
        """
        response = requests.post(
            f"https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key={api_key}",
            headers={"Content-Type": "application/json"},
            json={"contents": [{"parts": [{"text": prompt}]}]}
        )
        response.raise_for_status()
        data = response.json()
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as e:
        return f"⚠️ Error from Gemini API: {e}"

