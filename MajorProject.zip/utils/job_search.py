import urllib.parse

def generate_google_search_link(skills, role, location="Remote"):
    """
    Generate a Google search URL for jobs based on extracted skills and role.
    """
    query = f"{role} {' '.join(skills)} jobs in {location}"
    encoded_query = urllib.parse.quote_plus(query)
    return f"https://www.google.com/search?q={encoded_query}"
