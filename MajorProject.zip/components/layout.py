import streamlit as st

def display_user_info(info):
    """Display basic contact info extracted from resume."""
    if info.get("email"):
        st.write(f"📧 **Email:** {info['email']}")
    if info.get("phone"):
        st.write(f"📞 **Phone:** {info['phone']}")
    if not info.get("email") and not info.get("phone"):
        st.write("❌ No contact information found.")

def display_skills(skills):
    """Display extracted skills from resume."""
    st.subheader("🛠️ Extracted Skills")
    if skills:
        st.write(", ".join(sorted(skills)))
    else:
        st.warning("No skills found.")

def display_ats_score(score, missing_keywords):
    """Display ATS score and clearly list missing mandatory and optional skills."""
    st.metric(label="📊 ATS Score", value=f"{score:.2f}")

    missing_mandatory = missing_keywords.get("mandatory", [])
    missing_optional = missing_keywords.get("optional", [])

    if missing_mandatory or missing_optional:
        st.info("🚫 **Missing skills:**")
        if missing_mandatory:
            st.markdown(f"**Mandatory:** {', '.join(missing_mandatory)}")
        if missing_optional:
            st.markdown(f"**Optional:** {', '.join(missing_optional)}")
    else:
        st.success("✅ All required keywords matched!")

