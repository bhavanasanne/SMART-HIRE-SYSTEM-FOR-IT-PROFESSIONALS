import streamlit as st
from utils import parser, scoring, job_search, huggingface_helper
from components import layout
import json
import os
import re
from utils.token_tracker import get_token_summary

if "hf_api_calls" not in st.session_state:
    st.session_state.hf_api_calls = 0
if "hf_token_count" not in st.session_state:
    st.session_state.hf_token_count = 0

    
# Load ATS keywords
with open("data/ats_keywords.json") as f:
    ats_keywords = json.load(f)

# Load Gemini API key
# Load Hugging Face API key
hf_api_key = ""
if os.path.exists(".streamlit/secrets.toml"):
    try:
        import toml
        secrets = toml.load(".streamlit/secrets.toml")
        hf_api_key = secrets.get("HF_API_KEY", "")
    except:
        hf_api_key = ""

def extract_experience(text):
    match = re.search(r"(\d+(?:\.\d+)?)\s*(?:\+)?\s*years?", text, re.IGNORECASE)
    if match:
        return float(match.group(1))
    return None

def classify_experience(years):
    if years == 0:
        return "Fresher"
    elif years <= 2:
        return "Junior"
    elif years <= 5:
        return "Mid-Level"
    elif years <= 10:
        return "Senior"
    else:
        return "Expert"

# ---------------- Streamlit UI ----------------
st.set_page_config(layout="wide", page_title="Resume Analyzer")
st.markdown("<h1 style='text-align:center;'>Smart Hire System for IT professionals</h1>", unsafe_allow_html=True)

with st.container():
    col1, col2 = st.columns([2, 1])
    with col1:
        file = st.file_uploader("📤 Upload your Resume (PDF)", type="pdf")
    with col2:
        location = st.selectbox("🌍 Preferred Job Location", ["Remote", "On-site", "Hybrid", "Other"])
        if location == "Other":
            location = st.text_input("Enter Custom Location")

if file:
    text = parser.extract_text_from_pdf(file)
    info = parser.extract_basic_info(text)

    with st.container():
        st.subheader("👤 Contact Info")
        layout.display_user_info(info)

    experience = extract_experience(text)
    with st.container():
        st.subheader("💼 Experience")
        if experience is None:
            experience = st.number_input("Enter your years of experience:", min_value=0.0, max_value=50.0, step=0.5)
        level = classify_experience(experience)
        st.success(f"🧠 **{experience} years** — Level: **{level}**")

    with st.container():
        all_keywords = set().union(*[v["mandatory"] + v["optional"] for v in ats_keywords.values()])
        skills = parser.extract_skills(text, all_keywords)
        layout.display_skills(skills)

    with st.container():
        best_role = scoring.find_best_role(skills, ats_keywords)
        st.subheader("🔎 Best Matched Role: " + best_role)

    if best_role in ats_keywords:
        keywords = ats_keywords[best_role]
        score = scoring.calculate_weighted_ats_score(skills, keywords)
        missing = scoring.get_missing_keywords(skills, keywords)

        with st.container():
            #st.subheader("📊 ATS Score")
            layout.display_ats_score(score, missing)

        url = job_search.generate_google_search_link(skills, best_role, location)
        st.markdown(f"[🔍 Google Job Search for {best_role}]({url})", unsafe_allow_html=True)

        if hf_api_key:
            with st.expander("✨ AI Suggestions (Hugging Face)"):
                if st.button("💡 Improve Resume"):
                    st.write(huggingface_helper.suggest_resume_improvements(text, best_role, hf_api_key))
                if st.button("🔍 Suggest Skills"):
                    st.write(huggingface_helper.suggest_skills_to_add(text, best_role, hf_api_key))
        else:
            st.info("🔐 Add your Hugging Face API key to `.streamlit/secrets.toml` or environment to unlock AI suggestions.")

    else:
        st.warning("⚠️ No matching role found. Please enhance your resume.")
else:
    st.info("📥 Please upload your resume to get started.")
